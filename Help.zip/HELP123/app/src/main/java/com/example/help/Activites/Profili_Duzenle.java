package com.example.help.Activites;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Profili_Duzenle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profili__duzenle);
    }
}
